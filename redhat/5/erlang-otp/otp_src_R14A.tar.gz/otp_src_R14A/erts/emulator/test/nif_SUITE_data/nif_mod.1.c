#define NIF_LIB_VER 1
#include "nif_mod.c"
